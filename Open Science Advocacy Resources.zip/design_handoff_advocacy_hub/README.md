# Handoff: COS Open Science Advocacy Resource Hub

## Overview

A public web page that organizes the Center for Open Science's policy advocacy materials (Congressional testimony, RFI responses, policy briefs, analyses) into a tool open science advocates can actually use.

It has two parts:

1. **Landing / talking points** — the three things COS advocates for, each with 4 talking points drawn from the filings, so an advocate can grab language for their own comment, memo, or meeting.
2. **Resource library** — every filing in one searchable, multi-filter list (search + ask + agency + format).

Target audiences: researchers/faculty advocating inside their institution, grad students and early-career researchers, and policy makers/funders. Copy tone is plain-spoken and practical.

**Target deployment:** `webmz/cos-policy-resources.github.io` — a GitHub Pages site currently using Jekyll with `remote_theme: pages-themes/cayman@v0.2.0`. See "Implementation notes" below.

## About the Design Files

`COS Advocacy Hub.dc.html` in this bundle is a **design reference created in HTML** — a working prototype showing intended look and behavior, not production code to copy verbatim. It uses a component runtime (a template + a logic class) that will not exist in the target repo.

The task is to **recreate this design in the target environment**. For this project that environment is a static GitHub Pages site, so the natural implementation is:

- One `index.html` (or a Jekyll layout + page) with the markup, hand-written CSS in `assets/css/`, and a small vanilla-JS file for search/filter.
- No build step, no framework, no npm — GitHub Pages serves it directly.
- The existing Cayman `remote_theme` should be **dropped or overridden** for this page; the design is a full custom layout, not a themed document. Keep `_config.yml`'s `title`/`description`.
- Resource documents (PDF/DOCX) should be committed into a `/resources/` folder in the repo and linked from there. In the prototype they point at temporary `uploads/…` paths — **these must be replaced.** See "Assets".

If the team would rather use a framework, any of React/Vue/Astro/Eleventy would work; the design has no requirements beyond client-side filtering.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, and interactions. Recreate pixel-accurately. All values below are exact.

---

## Design Tokens

### Colors

| Token | Hex | Use |
| --- | --- | --- |
| COS blue | `#1532eb` | Header background, primary buttons, links, section kickers, active filter chips, pillar top border |
| COS cyan | `#15a5eb` | "Writing your own comment?" CTA band background, pillar number, "Assessment reform" tag, link hover |
| COS yellow | `#ffd100` | Hero eyebrow text, hero primary button, bullet squares, footer license link, text selection |
| Ink | `#14161c` | Body text, footer background, yellow-button text |
| Ink muted | `#4a4f5c` | Secondary paragraph text, inactive chip text |
| Grey text | `#8a909e` | Meta labels, dates, formats, placeholder circle |
| Border | `#e7e9ee` | Card borders, list dividers, pillar point dividers, filter bar underline |
| Border strong | `#c9cdd7` | Search input border, inactive chip border, empty-state dashed border |
| Surface | `#f6f7f9` | "Three asks" section background, list-row hover |
| White | `#ffffff` | Page background, card backgrounds |
| Dark gold | `#b8860b` | "Open infrastructure" tag text |

These are the COS brand colors already present in the repo's `assets/css/style.scss` (`#1532EB`, `#15A5EB`, `#FFD100`).

Overlay colors on blue/cyan/dark backgrounds: `rgba(255,255,255,0.88)` hero body, `rgba(255,255,255,0.92)` CTA body, `rgba(255,255,255,0.7)` stat labels & footer text, `rgba(255,255,255,0.55)` footer disclosure, `rgba(255,255,255,0.6)` / `rgba(255,255,255,0.5)` ghost-button borders, `rgba(255,255,255,0.18)` header nav divider, `rgba(255,255,255,0.2)` stat-block gaps, `rgba(255,255,255,0.15)` footer disclosure divider.

### Typography

**Open Sans only** (Google Fonts, weights 300/400/500/600/700). Fallback stack: `"Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif`. COS uses no other typeface — do not introduce a mono or display font.

```html
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

| Role | Size / weight / line-height | Notes |
| --- | --- | --- |
| Hero h1 | 64px / 300 / 1.06 | `letter-spacing:-0.02em`, `text-wrap:balance` |
| Hero body | 21px / 300 / 1.5 | `max-width:60ch` |
| Section h2 | 40px / 300 / 1.12 | `letter-spacing:-0.015em` |
| Section body | 19px / 300 / 1.55 | color `#4a4f5c` |
| Pillar h3 | 29px / 400 / 1.18 | `letter-spacing:-0.01em` |
| Pillar summary | 17px / 300 / 1.6 | color `#4a4f5c` |
| Talking point | 17px / 400 / 1.55 | `text-wrap:pretty` |
| Card h3 | 21px / 500 / 1.25 | `letter-spacing:-0.005em`, `text-wrap:pretty` |
| Card blurb | 16px / 300 / 1.55 | color `#4a4f5c`, `flex:1` |
| CTA h2 | 34px / 300 / 1.15 | `letter-spacing:-0.015em` |
| Buttons / CTA links | 16px / 500–600 | 600 on filled, 500 on ghost |
| Eyebrow / kicker | 13px / 400–600, `letter-spacing:0.1em`, `text-transform:uppercase` | Replaces what would be a mono label |
| Meta (agency, date, format, tags) | 12px / 500–600, `letter-spacing:0.04–0.08em`, uppercase | |
| Filter chip | 14px / 500 | |
| Result count / Clear all | 13px | |
| Footer | 15px / 300 | |
| Footer disclosure | 13px / 300 / 1.6 | |

### Spacing & layout

- Content column: `max-width:1180px`, `margin:0 auto`, horizontal padding `32px`.
- Section vertical padding: hero `88px top / 96px bottom`; three-asks `84px / 92px`; library `84px top / 40px bottom`; CTA band section `20px / 84px`; footer `44px`.
- Radius: **0 everywhere.** No rounded corners except the two decorative circles (the yellow header dot, `13px`, and the search-icon ring, `12px`, both `border-radius:50%`).
- Shadows: **none.** Depth comes from 1px borders and flat color blocks.
- Grid gaps: pillar cards `28px`; card grid `24px`; hero columns `56px`; pillar internal columns `44px`; CTA band columns `48px`.

---

## Screens / Views

Single scrolling page, four regions plus footer.

### 1. Site header + hero (`<header>`, background `#1532eb`, white text)

**Nav bar** — inside the 1180px column, `padding:22px 32px`, `display:flex`, `justify-content:space-between`, `gap:24px`, bottom border `1px solid rgba(255,255,255,0.18)`.
- Left: a `13px` yellow (`#ffd100`) circle + "CENTER FOR OPEN SCIENCE" — 14px, weight 600, `letter-spacing:0.14em`, uppercase, `gap:14px`.
- Right: nav links, `display:flex`, `gap:26px`, 15px weight 500, no underline. "What we advocate for" → `#pillars`, "Resource library" → `#library` (both white), "Policy reform ↗" → `https://www.cos.io/policy-reform` (yellow `#ffd100`).

**Hero** — `padding:88px 32px 96px`, `display:grid`, `grid-template-columns:minmax(0,1.25fr) minmax(0,0.75fr)`, `gap:56px`, `align-items:end`.

Left column:
- Eyebrow: "ADVOCACY TOOLKIT · OPENLY LICENSED CC BY 4.0" — 13px, `letter-spacing:0.1em`, uppercase, `#ffd100`, `margin-bottom:22px`.
- H1: "Make the case for open science — with arguments we've already made in public."
- Body: "COS files public comments, RFI responses, and analyses with federal agencies. Everything is here, sorted by the three things we argue for, so you can borrow the language for your own comment, memo, or meeting."
- Buttons (`display:flex`, `gap:14px`, `margin-top:38px`, wrap):
  - "Start with the talking points" → `#pillars`. Background `#ffd100`, text `#14161c`, weight 600, 16px, `padding:15px 26px`.
  - "Browse all documents" → `#library`. Transparent, `1px solid rgba(255,255,255,0.5)`, white, weight 500, same padding.

Right column — three stat blocks, `display:flex; flex-direction:column; gap:1px`, wrapper background `rgba(255,255,255,0.2)` so the 1px gaps read as hairlines; each block `background:#1532eb; padding:20px 22px`.
- `12` / "PUBLIC DOCUMENTS" — count of resources (computed).
- `7` / "AGENCIES & BODIES" — count of unique agencies (computed).
- `3` / "POLICY ASKS" — literal.
- Number: 38px weight 300, `line-height:1`. Label: 13px, `letter-spacing:0.08em`, uppercase, `rgba(255,255,255,0.7)`, `margin-top:4px`.

### 2. The three asks (`<section id="pillars">`, background `#f6f7f9`)

Intro block, `max-width:70ch`, `margin-bottom:52px`:
- Kicker "THE THREE ASKS" (13px, `letter-spacing:0.1em`, uppercase, `#1532eb`, `margin-bottom:16px`)
- H2 "Everything COS files comes back to three things."
- Body "Each ask below carries the talking points we use, drawn straight from the filings. Take a point, use the source document for detail."

Then three stacked `<article>` cards, `display:grid; gap:28px`. Each card: `background:#fff`, `border-top:5px solid #1532eb`, `padding:38px 40px 40px`, `display:grid`, `grid-template-columns:minmax(0,0.9fr) minmax(0,1.5fr)`, `gap:44px`.

Card left column:
- Row (`display:flex; align-items:baseline; gap:12px; margin-bottom:16px`): number ("01") 13px weight 500 `#15a5eb`; kicker ("ASK ONE") 12px `letter-spacing:0.1em` uppercase `#8a909e`.
- H3 title, then 17px/300 summary (`margin-bottom:24px`).
- Button: transparent, `1px solid #1532eb`, text `#1532eb`, 15px weight 500, `padding:11px 18px`, `font-family:inherit`, `cursor:pointer`. Label: "See the N documents behind this" where N = documents tagged with that ask (4, 4, 6 respectively). **Hover:** background `#1532eb`, text `#fff`. **Click:** sets the library's ask filter to only this ask, clears every other filter and the search box, then smooth-scrolls to `#library` (offset −8px).

Card right column — the talking points, `display:flex; flex-direction:column`. Each point: `border-top:1px solid #e7e9ee`, `padding:18px 0`, `display:grid`, `grid-template-columns:22px minmax(0,1fr)`, `gap:16px`, `align-items:start`.
- Marker: a `9px × 9px` **square** of `#ffd100`, `margin-top:8px` (not a circle, not a bullet glyph).
- Text: 17px/1.55, `text-wrap:pretty`.
- Optional source caption below: "Source: <document title>", 12px, `#8a909e`, `margin-top:8px`. Shown only when the point has a source **and** the `showPillarSources` flag is on (default on).

Exact content for all three pillars is in the `PILLARS` array in the prototype's logic class — copy the strings verbatim; they are the deliverable.

### 3. Resource library (`<section id="library">`)

Intro block (`max-width:60ch`): kicker "RESOURCE LIBRARY", H2 "Every filing, searchable.", body "Filter by ask, by agency, or by format. All documents are CC BY 4.0 — reuse the text with attribution."

**Sticky filter bar** — `position:sticky; top:0; z-index:5; background:#fff; padding:18px 0 20px; border-bottom:1px solid #e7e9ee; margin-bottom:30px`.

Row 1 (`display:flex; gap:14px; align-items:center`, wrap):
- Search field: `flex:1 1 300px`, `1px solid #c9cdd7`, `padding:13px 16px`, `display:flex; align-items:center; gap:12px`. Inside: a `12px` circle with `2px solid #8a909e` border and `border-radius:50%` (the search glyph — a magnifier icon is fine if the codebase has one), then a borderless transparent `<input type="text">` at 17px with `outline:none; width:100%`, placeholder "Search titles, agencies, arguments…".
- Right group: result label (13px, `#8a909e`) reading "12 documents" when unfiltered, otherwise "N of 12"; and a "Clear all" text button — transparent, no border, `font-family:inherit`, 13px, `#1532eb`, underlined, `cursor:pointer`, `padding:6px 2px` — which resets all filters and empties the input.

Rows 2–4, one per filter group, `display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-top:14px`:
- Group label 12px, `letter-spacing:0.08em`, uppercase, `#8a909e`, fixed `width:82px; flex:none` — "ASK", "AGENCY", "FORMAT".
- Chips: `padding:8px 14px`, 14px weight 500, `cursor:pointer`, square. Inactive: `background:#fff`, `color:#4a4f5c`, `1px solid #c9cdd7`. Active: `background:#1532eb`, `color:#fff`, `1px solid #1532eb`.
- Ask chips: "TOP Guidelines", "Assessment reform", "Open infrastructure".
- Agency chips (derived from the data, in first-appearance order): OSTP, NSF, NIH, NASA, U.S. Senate, OMB.
- Format chips (same): Analysis, RFI response, Comment.

**Results — card grid (default).** `display:grid; grid-template-columns:repeat(auto-fill, minmax(330px, 1fr)); gap:24px`. Each card: `border:1px solid #e7e9ee`, `padding:26px 26px 24px`, `background:#fff`, `display:flex; flex-direction:column; gap:14px`. **Hover:** `border-color:#1532eb`.
1. Meta row — `display:flex; justify-content:space-between; align-items:baseline; gap:14px`, 12px, `letter-spacing:0.06em`, uppercase: agency (`#1532eb`, weight 500) and date (`#8a909e`).
2. Title (21px/500).
3. Blurb (16px/300, `#4a4f5c`, `flex:1` so footers align).
4. Topic tags — `display:flex; gap:8px; flex-wrap:wrap`. Each: 12px weight 600, `letter-spacing:0.04em`, uppercase, `padding:4px 9px`, `border:1px solid currentColor`, no fill. Color by topic: TOP Guidelines `#1532eb`, Assessment reform `#15a5eb`, Open infrastructure `#b8860b`.
5. Footer — `border-top:1px solid #e7e9ee`, `padding-top:16px`, `display:flex; gap:16px; align-items:center`: link "Read the filing ↗" (16px weight 600, `target="_blank"`) and the format (12px, `#8a909e`, uppercase).

**Results — compact list (alternate).** One row per document: `display:grid; grid-template-columns:110px minmax(0,1fr) 220px 130px; gap:22px; align-items:baseline; padding:20px 4px; border-bottom:1px solid #e7e9ee`. Hover `background:#f6f7f9`. Columns: agency (12px uppercase `#1532eb`), title as link (18px/500), topic line (topic labels joined with " · ", 14px/300 `#4a4f5c`), date (12px `#8a909e`, right-aligned).

**Empty state** (zero matches, replaces the results): `1px dashed #c9cdd7`, `padding:56px 32px`, centered. "Nothing matches those filters." (20px/300) and "Try removing a filter, or search for an agency name." (16px, `#8a909e`).

### 4. CTA band (`<section>`, `padding:20px 32px 84px`)

Inside the 1180px column: `background:#15a5eb`, white text, `padding:52px 48px`, `display:grid`, `grid-template-columns:minmax(0,1.3fr) minmax(0,1fr)`, `gap:48px`, `align-items:center`.
- Left: H2 "Writing your own comment?" then body "Public comment is one of the few places a single researcher's argument lands directly in front of the people writing the policy. Quote these filings, adapt them to your field, and file under your own name."
- Right: `display:flex; flex-direction:column; gap:12px`, both `display:block`, `padding:15px 22px`, 16px.
  - "Find an open comment period ↗" → `https://www.regulations.gov`. White background, `#1532eb` text, weight 600.
  - "Read the TOP Guidelines ↗" → `https://www.cos.io/initiatives/top-guidelines`. Transparent, `1px solid rgba(255,255,255,0.6)`, white, weight 500.

### 5. Footer (`background:#14161c`, `padding:44px 32px`)

Row 1 — `display:flex; justify-content:space-between; gap:32px; flex-wrap:wrap`, 15px/300, `rgba(255,255,255,0.7)`:
- "Center for Open Science · 6218 Georgia Avenue NW, Washington, DC 20011"
- Link group (`gap:24px`): "CC BY 4.0" (yellow) → creativecommons.org/licenses/by/4.0/, "contact@cos.io" (white) → mailto, "cos.io" (white) → cos.io.

Row 2 — AI disclosure. `margin:28px auto 0`, `padding-top:22px`, `border-top:1px solid rgba(255,255,255,0.15)`, 13px/300/1.6, `rgba(255,255,255,0.55)`:

> "This page was designed and built with the assistance of Claude, an AI assistant made by Anthropic. The talking points summarize positions COS has stated in the public filings linked above; the filings themselves are the authoritative source."

---

## Interactions & Behavior

- **Search** — fires on every keystroke (`input`), case-insensitive substring match against title + agency + blurb + format + topic labels concatenated. Keep the input **uncontrolled** (no value binding) so the caret never jumps; hold the query in state and clear the DOM value via a ref on reset.
- **Filters** — three independent multi-select groups. Within a group, chips are OR'd; across groups, AND'd. A document passes an ask filter if **any** of its topics is selected. Empty group = no constraint.
- **Pillar CTA** — sets ask filter to that single ask, clears agency/format/search, smooth-scrolls to the library.
- **Result label** — "12 documents" unfiltered, "N of 12" otherwise.
- **Clear all** — empties all four state values and the input.
- **Hover states** — pillar button inverts to solid blue; resource card border goes blue; list rows tint `#f6f7f9`; links go `#1532eb` → `#15a5eb` with the underline color following.
- **Global link styling** — set `a`/`a:hover` explicitly (`#1532eb` / `#15a5eb`, `text-decoration-color: rgba(21,50,235,0.35)` → `#15a5eb`, `text-underline-offset:3px`). `::selection` is `#ffd100` on `#14161c`.
- **No animations** other than the smooth scroll. No loading or error states — all data is static and inlined.
- **Responsive** — the prototype is desktop-first with wrapping flex rows. Not yet specified for mobile; recommended: collapse every two-column grid to one column below ~860px, drop hero H1 to ~40px, section H2 to ~30px, let the card grid fall to one column, and make the filter bar's group labels stack above their chips. Worth confirming with the designer before shipping.

## State Management

Four values, all client-side, no persistence or fetching:

```js
{ q: "",          // search string
  topics: [],     // selected ask keys: "top" | "assessment" | "infra"
  agencies: [],   // selected agency strings
  formats: [] }   // selected format strings
```

Derived per render: filtered results, the three chip groups with active flags, result label, and the empty/cards/list branch. Plus a ref to the search input so "Clear all" and the pillar CTAs can blank it.

Three build-time options exist as component props in the prototype and can become plain constants:
- `accentColor` (default `#15a5eb`) — colors the "Assessment reform" tag.
- `libraryDensity` — `"Cards"` (default) or `"List"`.
- `showPillarSources` (default `true`) — show/hide the "Source:" captions.

## Content / Data

The 12 documents live in the `RESOURCES` array in the prototype's logic class, each with `title`, `agency`, `date`, `format`, `topics[]`, `file`, `blurb`. The `PILLARS` array holds the three asks with their titles, summaries, and talking points. **Both arrays are the actual content deliverable — lift them verbatim.**

Two caveats carried over from the design phase:
1. Dates on several cards are **inferred** from notice numbers (e.g. `NOT-AG-24-013` → 2024). COS should verify each before publishing.
2. Two documents (the null-studies RFI and the Measuring & Rewarding Scientific Impact RFI) could not be opened during design, so their blurbs were written from their titles. Confirm accuracy.

The three asks are quoted from the repo's own `README.md`; talking points are paraphrased from the filings (the OSTP "Nelson" memo assessment and the NSF Public Access Plan 2.0 response were read in full).

## Assets

- **Fonts:** Open Sans via Google Fonts. Self-host if the site should work without third-party requests.
- **Icons:** none. Every mark is a plain CSS box or circle; the arrows are the `↗` character (`&#8599;`).
- **Images:** none. The existing repo's `style.scss` referenced a cos.io hero JPEG for the Cayman page header; this design uses a flat blue hero instead and does not need it.
- **Documents:** the 12 PDFs/DOCX. In the prototype they point at temporary `uploads/resources-…` paths that **will not exist** in the repo. Commit them to `/resources/` with readable filenames and update each `file:` value. All are CC BY 4.0 and safe to host.
- **Logo:** the design uses a wordmark in type, not an image. If COS prefers the real logo, `https://www.cos.io/hubfs/Logos/COS%202024/cos-full-tag-h-w.png` is the white horizontal version.

## Implementation notes for the target repo

`webmz/cos-policy-resources.github.io` currently contains only `README.md`, `_config.yml`, `assets/css/style.scss`, and `LICENSE`, rendering through the Cayman remote theme. Suggested shape:

```
index.html                 # or index.md + a custom _layouts/hub.html
assets/css/hub.css         # replaces the Cayman override in style.scss
assets/js/library.js       # search + filter
resources/*.pdf|*.docx     # the 12 filings
_data/resources.yml        # optional: move RESOURCES out of JS into Jekyll data
```

Moving the resource list into `_data/resources.yml` is worth doing — it lets COS staff add a filing by editing YAML rather than JavaScript, and Jekyll can render the cards server-side while the JS only handles show/hide.

Keep `README.md` accurate: it is the canonical statement of the three asks and the source of the pillar headings.

## Files in this bundle

- `COS Advocacy Hub.dc.html` — the design reference. Its `<x-dc>` block is the markup, and the trailing `<script type="text/x-dc">` block holds the `TOPICS` / `RESOURCES` / `PILLARS` data and the filter logic. Open it in a browser to see the live design.
- `github.md` — the repo association record (repo, branch, last sync, screen map).
