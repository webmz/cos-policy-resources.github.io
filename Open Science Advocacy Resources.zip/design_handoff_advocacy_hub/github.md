repo: webmz/cos-policy-resources.github.io
branch: main

## Last sync
date: 2026-08-27T13:20:00Z

### Updated in this project
- Built "COS Advocacy Hub" landing + searchable resource library from the repo's README and 13 uploaded COS filings.
- Adopted the repo's COS brand colors (#1532EB, #15A5EB, #FFD100) from assets/css/style.scss.
- Structured the landing page around the three key advocacy topics stated verbatim in README.md.

## Screen map
| Screen | Repo files |
| --- | --- |
| COS Advocacy Hub.dc.html — hero + three asks | README.md, _config.yml |
| COS Advocacy Hub.dc.html — palette & type | assets/css/style.scss |
| COS Advocacy Hub.dc.html — resource library | (documents from uploads/, not yet in repo) |
